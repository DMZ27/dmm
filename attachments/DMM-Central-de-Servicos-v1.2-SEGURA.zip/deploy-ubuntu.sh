#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y ca-certificates curl git docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo mkdir -p /opt/dmm-central-servicos
sudo chown -R "$USER":"$USER" /opt/dmm-central-servicos
cd /opt/dmm-central-servicos
# Copy this project here before running the script.
cp -n .env.example .env || true
nano .env
sudo docker compose up -d --build
