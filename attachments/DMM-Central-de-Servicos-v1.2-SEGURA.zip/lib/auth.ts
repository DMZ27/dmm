import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { db } from './db';
const authSecret = process.env.AUTH_SECRET;
if (!authSecret && process.env.NODE_ENV === 'production') throw new Error('AUTH_SECRET não configurado.');
const secret = new TextEncoder().encode(authSecret || 'development-only-secret-change-me');
export async function createSession(user:{id:string,role:string}){
  const token=await new SignJWT({sub:user.id,role:user.role}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('7d').sign(secret);
  (await cookies()).set('dmm_session',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:60*60*24*7,path:'/'});
}
export async function getSession(){
  const token=(await cookies()).get('dmm_session')?.value; if(!token) return null;
  try { const {payload}=await jwtVerify(token,secret); if(!payload.sub) return null; return db.user.findUnique({where:{id:String(payload.sub)}}); } catch { return null; }
}
export async function requireUser(){ const u=await getSession(); if(!u) throw new Error('UNAUTHORIZED'); return u; }
