import nodemailer from 'nodemailer';
export async function sendPasswordResetEmail(to:string, resetUrl:string){
 const {SMTP_HOST,SMTP_PORT,SMTP_USER,SMTP_PASSWORD,SMTP_FROM}=process.env;
 if(!SMTP_HOST||!SMTP_USER||!SMTP_PASSWORD) return false;
 const transporter=nodemailer.createTransport({host:SMTP_HOST,port:Number(SMTP_PORT||587),secure:Number(SMTP_PORT||587)===465,auth:{user:SMTP_USER,pass:SMTP_PASSWORD}});
 await transporter.sendMail({from:SMTP_FROM||SMTP_USER,to,subject:'Redefinição de senha — DMM Central de Serviços',text:`Recebemos um pedido para redefinir a sua senha.

Abra este link para definir uma nova senha:
${resetUrl}

O link expira em 30 minutos. Se não pediu isto, ignore esta mensagem.`});
 return true;
}
