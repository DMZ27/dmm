import { mkdir, writeFile } from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

export const MAX_FILE_SIZE=25*1024*1024;
export const MAX_ORDER_UPLOAD_BYTES=50*1024*1024;
export const ALLOWED_TYPES=new Set(['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','image/jpeg','image/png','image/webp','text/plain','application/zip']);
export const ALLOWED_EXT=new Set(['pdf','doc','docx','xls','xlsx','ppt','pptx','jpg','jpeg','png','webp','txt','zip']);
export function safeExtension(name:string){const ext=path.extname(name).slice(1).toLowerCase(); if(!ALLOWED_EXT.has(ext)) throw new Error('TIPO_DE_FICHEIRO_NAO_PERMITIDO'); return ext;}
export function validateFile(file:File){if(file.size<=0) throw new Error('FICHEIRO_VAZIO'); if(file.size>MAX_FILE_SIZE) throw new Error('FICHEIRO_MUITO_GRANDE'); if(!ALLOWED_TYPES.has(file.type)) throw new Error('TIPO_DE_FICHEIRO_NAO_PERMITIDO'); const ext=safeExtension(file.name); return ext;}
export async function storeFile(orderId:string,file:File,kind:'INPUT'|'FINAL'|'PAYMENT_PROOF'){const ext=validateFile(file); const dir=path.join(process.cwd(),'storage','uploads',orderId); await mkdir(dir,{recursive:true}); const filename=`${crypto.randomUUID()}.${ext}`; const storagePath=path.join(dir,filename); await writeFile(storagePath,Buffer.from(await file.arrayBuffer())); return {storagePath,url:'PRIVATE',name:file.name,mimeType:file.type,size:file.size,kind};}
