import { z } from 'zod';
export const emailSchema=z.string().trim().email().max(254).transform(v=>v.toLowerCase());
export const passwordSchema=z.string().min(8,'A senha deve ter pelo menos 8 caracteres.').max(128);
export const nameSchema=z.string().trim().min(2).max(120);
export const phoneSchema=z.string().trim().max(30).optional().or(z.literal(''));
export const orderSchema=z.object({serviceId:z.string().min(1),title:z.string().trim().min(3).max(180),description:z.string().trim().max(5000).optional(),formData:z.string().max(20000).optional()});
export const messageSchema=z.object({orderId:z.string().min(1),body:z.string().trim().min(1).max(4000)});
