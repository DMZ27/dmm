# Nota de build

O projecto está preparado para builds reprodutíveis com `npm ci` quando `package-lock.json` estiver presente. Nesta sessão o registry npm não estava acessível, por isso não foi criado um lock artificial.

Na sua máquina, dentro da pasta do projecto:

```bash
npm install
npm run build
npm run test:smoke
```

Depois, guarde o `package-lock.json` junto do projecto. A partir daí o Dockerfile usa `npm ci` automaticamente.
