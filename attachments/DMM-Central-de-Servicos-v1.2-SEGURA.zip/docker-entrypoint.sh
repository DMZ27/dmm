#!/bin/sh
set -eu
until npx prisma migrate deploy; do echo "Aguardando PostgreSQL..."; sleep 2; done
node prisma/seed.mjs
exec "$@"
