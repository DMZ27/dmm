#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p backups
docker compose exec -T postgres pg_dump -U "${POSTGRES_USER:-dmm}" "${POSTGRES_DB:-dmm_services}" > "backups/dmm-$(date +%Y%m%d-%H%M%S).sql"
tar -czf "backups/uploads-$(date +%Y%m%d-%H%M%S).tar.gz" public/uploads
echo "Backup criado em backups/"
