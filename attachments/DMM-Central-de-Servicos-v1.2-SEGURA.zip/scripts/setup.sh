#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET=$(openssl rand -hex 48)
  PASS=$(openssl rand -hex 18)
  sed -i "s#COLOQUE-AQUI-UMA-CHAVE-LONGA-E-ALEATORIA#$SECRET#" .env
  sed -i "s#COLOQUE-AQUI-UMA-SENHA-FORTE#$PASS#" .env
  sed -i "s#MUDE-ESTA-SENHA-FORTE#$(openssl rand -hex 18)#" .env
  echo "
.env criado com credenciais aleatórias. GUARDE a senha ADMIN_PASSWORD antes de continuar."
fi
docker compose up -d --build
echo "
DMM iniciado em http://localhost:3000"
