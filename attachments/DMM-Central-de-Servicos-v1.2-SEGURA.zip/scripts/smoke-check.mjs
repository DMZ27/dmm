import fs from 'node:fs'; import path from 'node:path';
const required=['package.json','package-lock.json','Dockerfile','docker-compose.yml','prisma/schema.prisma','prisma/migrations/migration_lock.toml','app/api/files/[id]/route.ts','storage/.gitkeep'];
const missing=required.filter(x=>!fs.existsSync(x));
if(fs.existsSync('public/uploads')) throw new Error('public/uploads não deve existir no armazenamento de produção.');
if(!fs.existsSync('storage/uploads')) throw new Error('storage/uploads em falta.');
if(missing.length){const lockOnly=missing.length===1&&missing[0]==='package-lock.json'; if(!lockOnly) throw new Error('Ficheiros em falta: '+missing.join(', ')); console.warn('AVISO: package-lock.json ainda não foi gerado neste ambiente.');}
const compose=fs.readFileSync('docker-compose.yml','utf8'); if(!compose.includes('condition: service_healthy')) throw new Error('Postgres readiness não configurado.');
console.log('Smoke check OK');
