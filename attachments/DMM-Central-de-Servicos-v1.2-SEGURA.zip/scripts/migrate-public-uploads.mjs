import fs from 'node:fs/promises'; import path from 'node:path'; import {PrismaClient} from '@prisma/client';
const db=new PrismaClient(); const root=path.join(process.cwd(),'public','uploads'); const target=path.join(process.cwd(),'storage','uploads');
async function walk(dir){const out=[];for(const e of await fs.readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())out.push(...await walk(p));else out.push(p)}return out}
try{
 const exists=await fs.access(root).then(()=>true).catch(()=>false); if(!exists){console.log('Nenhum public/uploads antigo encontrado.');process.exit(0)}
 const files=await walk(root); let moved=0;
 for(const oldPath of files){const rel=path.relative(root,oldPath).split(path.sep);const orderId=rel.shift();if(!orderId||orderId==='.gitkeep')continue;const oldUrl=`/uploads/${orderId}/${path.basename(oldPath)}`; const file=await db.orderFile.findFirst({where:{orderId,url:oldUrl}});if(!file)continue;const destDir=path.join(target,orderId);await fs.mkdir(destDir,{recursive:true});const dest=path.join(destDir,path.basename(oldPath));await fs.rename(oldPath,dest);if(file.storagePath==='')await db.orderFile.update({where:{id:file.id},data:{storagePath:dest}});moved++;}
 console.log(`Migração concluída: ${moved} ficheiros movidos.`);
}finally{await db.$disconnect()}
