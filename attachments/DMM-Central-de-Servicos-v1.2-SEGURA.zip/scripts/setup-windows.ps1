$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Test-Path .env)) {
  Copy-Item .env.example .env
  $secret = [Convert]::ToHexString((1..48 | ForEach-Object { Get-Random -Maximum 256 }))
  $admin = [Convert]::ToBase64String((1..18 | ForEach-Object { Get-Random -Maximum 256 }))
  $lines = Get-Content .env
  $lines = $lines -replace 'COLOQUE-AQUI-UMA-CHAVE-LONGA-E-ALEATORIA', $secret
  $lines = $lines -replace 'COLOQUE-AQUI-UMA-SENHA-FORTE', $admin
  $lines = $lines -replace 'MUDE-ESTA-SENHA-FORTE', ([guid]::NewGuid().ToString('N') + 'Db!')
  Set-Content .env $lines
  Write-Host "`.env criado. Guarde a senha ADMIN_PASSWORD do arquivo `.env."
}
docker compose up -d --build
Write-Host "DMM iniciado em http://localhost:3000"
