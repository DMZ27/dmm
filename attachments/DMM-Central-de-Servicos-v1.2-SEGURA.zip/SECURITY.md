# DMM — Checklist de segurança

## Resolvido nesta revisão
- [x] Ficheiros privados fora de `public/`.
- [x] Download protegido por sessão e propriedade do pedido.
- [x] Limite de 25 MB por ficheiro e 50 MB por pedido.
- [x] Lista de tipos/extensões permitidos.
- [x] Alteração de senha para cliente e administrador.
- [x] Recuperação por email com token hash, único e expiração de 30 minutos.
- [x] Seed não repõe senha existente em cada arranque.
- [x] Rate limit de login.
- [x] Validação Zod em autenticação, pedidos, mensagens e orçamento.
- [x] Migrações Prisma versionadas.
- [x] PostgreSQL readiness/healthcheck.
- [x] Backup diário automático com retenção de 14 dias.
- [x] Headers HTTP de segurança básicos.
- [x] Termos e política de privacidade incluídos como textos-base.
- [x] Imagens convertidas de PNG pesado para WebP.

## Ainda depende do ambiente de produção
- `package-lock.json`: este ambiente não conseguiu aceder ao registry npm para gerar o lock. Antes do deploy final, execute `npm install` uma vez na máquina de desenvolvimento e confirme o `package-lock.json`; depois o Docker passa automaticamente a usar `npm ci`.
- HTTPS deve ser configurado no proxy reverso.
- SMTP deve ser configurado para recuperação por email.
- Backups devem ser copiados para um segundo local.
- Os textos legais devem ser revistos profissionalmente antes do lançamento comercial.
- Recomenda-se monitorização de erros e testes automatizados adicionais quando o volume de clientes crescer.
