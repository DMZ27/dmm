import {NextResponse} from 'next/server'; import {cookies} from 'next/headers';
export async function POST(){(await cookies()).set('dmm_session','',{httpOnly:true,expires:new Date(0),path:'/',sameSite:'lax'});return NextResponse.json({ok:true});}
