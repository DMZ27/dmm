import { NextResponse } from 'next/server';
import { db } from '@/lib/db'; import bcrypt from 'bcryptjs'; import { createSession } from '@/lib/auth'; import { emailSchema,passwordSchema } from '@/lib/validation'; import { checkLoginAllowed,clearLoginFailures,recordLoginFailure } from '@/lib/rate-limit';
export async function POST(req:Request){
 const ip=req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
 try{
  const body=await req.json(); const email=emailSchema.parse(body.email); const password=passwordSchema.parse(body.password); const key=`${ip}:${email}`;
  if(!(await checkLoginAllowed(key))) return NextResponse.json({error:'Demasiadas tentativas. Tente novamente dentro de 15 minutos.'},{status:429});
  const u=await db.user.findUnique({where:{email}}); if(!u || !(await bcrypt.compare(password,u.passwordHash))){await recordLoginFailure(key);return NextResponse.json({error:'Email ou senha incorretos.'},{status:401});}
  await clearLoginFailures(key); await createSession(u); return NextResponse.json({ok:true,role:u.role});
 }catch{return NextResponse.json({error:'Dados de acesso inválidos.'},{status:400});}
}
