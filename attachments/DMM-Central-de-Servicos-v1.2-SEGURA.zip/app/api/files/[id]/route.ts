import { db } from '@/lib/db'; import { getSession } from '@/lib/auth'; import { readFile } from 'fs/promises';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){
 const user=await getSession(); if(!user)return new Response('UNAUTHORIZED',{status:401});
 const {id}=await params; const file=await db.orderFile.findUnique({where:{id},include:{order:true}});
 if(!file)return new Response('Ficheiro não encontrado.',{status:404});
 if(user.role!=='ADMIN'&&file.order.userId!==user.id)return new Response('FORBIDDEN',{status:403});
 try{const data=await readFile(file.storagePath);const safe=file.name.replace(/["\r\n]/g,'_');return new Response(data,{headers:{'Content-Type':file.mimeType||'application/octet-stream','Content-Disposition':`attachment; filename="${safe}"`,'Cache-Control':'private, no-store'}});}catch{return new Response('Ficheiro indisponível.',{status:404});}
}
