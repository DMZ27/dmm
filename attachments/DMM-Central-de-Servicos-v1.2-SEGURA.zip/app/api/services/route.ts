import {NextResponse} from 'next/server'; import {db} from '@/lib/db'; export async function GET(){return NextResponse.json(await db.service.findMany({where:{active:true},orderBy:{category:'asc'}}))}
