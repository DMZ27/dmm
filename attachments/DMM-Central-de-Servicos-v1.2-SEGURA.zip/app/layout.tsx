import './globals.css';
import { Header, Footer } from '@/components/site';
export const metadata={title:'DMM — Ideias que se tornam resultados',description:'Central de serviços académicos, design e tecnologia em Benguela.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <><Header/><main>{children}</main><Footer/></>}
