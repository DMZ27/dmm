# DMM — Central de Serviços

Plataforma web responsiva para encomenda, orçamento, acompanhamento, comunicação e entrega de serviços.

## Stack
- Next.js 15 + React 19 + TypeScript
- PostgreSQL 17
- Prisma 6 com migrações versionadas
- Docker Compose
- Autenticação por cookie HttpOnly + JWT
- Upload privado fora de `public/`

## Segurança incluída
- Ficheiros privados em `storage/uploads/`; não são servidos como arquivos públicos.
- Download através de `/api/files/:id`, com validação de sessão e propriedade do pedido.
- Limite de 25 MB por ficheiro e 50 MB por pedido.
- Tipos de ficheiro permitidos explicitamente.
- Rate limit de login: 5 falhas por combinação IP/email em janela de 15 minutos.
- Senhas com mínimo de 8 caracteres e hash bcrypt.
- Alteração de senha autenticada.
- Recuperação de senha por email com token hash, uso único e validade de 30 minutos.
- Headers de segurança básicos.
- PostgreSQL com healthcheck e backup diário automático, retenção de 14 dias.
- Segredos somente no `.env`.

## Arranque local
1. Copie `.env.example` para `.env` e preencha os segredos.
2. Gere o `package-lock.json` com `npm install` se ele ainda não existir.
3. Execute `npm ci`.
4. Execute `docker compose up -d --build`.
5. Abra `http://localhost:3000`.

## Banco
O container executa `prisma migrate deploy` antes de iniciar a aplicação. O seed só cria o administrador inicial se o email ainda não existir; ele **não repõe a senha em cada arranque**.

## Recuperação de senha
Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` e `SMTP_FROM`. Sem SMTP, o pedido de recuperação responde de forma genérica mas nenhum email é enviado.

## Backups
O serviço `backup` cria um dump PostgreSQL por dia em `./backups` e remove dumps com mais de 14 dias. Em produção, copie também esses backups para outro local físico/cloud.

## Deploy Oracle
Consulte `DEPLOY-ORACLE.md`.

## Legal
Consulte `/privacidade` e `/termos`. Estes textos são uma base e devem ser revistos juridicamente antes do lançamento comercial, considerando a legislação aplicável.
