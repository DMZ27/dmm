#!/usr/bin/env bash
set -e
cp -n .env.example .env || true
npm install
npm run db:push
npm run db:seed
npm run dev
