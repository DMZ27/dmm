# Deploy no Oracle Cloud — DMM

## 1. Criar a VM
- Ubuntu Linux
- Shape Always Free elegível
- 2 OCPU / até 12 GB RAM dentro do limite A1 disponível
- IP público
- Chave SSH guardada fora do servidor

## 2. Instalar Docker no Ubuntu
Use o script `scripts/setup.sh` ou instale Docker Engine + Compose Plugin pelos pacotes oficiais do Ubuntu/Docker.

## 3. Copiar o projecto
Envie o ZIP para o servidor, extraia-o e entre na pasta.

## 4. Criar `.env`
Copie `.env.example` para `.env` e substitua todos os valores sensíveis. Gere um `AUTH_SECRET` longo e aleatório. Não publique `.env`.

## 5. Primeiro arranque
```bash
docker compose up -d --build
```
O PostgreSQL precisa ficar saudável antes da aplicação. A aplicação executa `prisma migrate deploy` e depois o seed idempotente.

## 6. Se existir uma instalação antiga
Antes de abrir o site ao público, mova os ficheiros antigos:
```bash
docker compose exec app node scripts/migrate-public-uploads.mjs
```
Depois confirme que não existe `public/uploads` com documentos de clientes. A versão nova não grava novos documentos nessa pasta.

## 7. HTTPS
Coloque Nginx ou Caddy na frente da aplicação e configure HTTPS. Em produção, defina `NEXT_PUBLIC_APP_URL` para a URL HTTPS final. Nunca use HTTP público para contas ou documentos.

## 8. Backups
O serviço `backup` cria um dump diário em `./backups` e mantém 14 dias. Copie regularmente esses dumps para um segundo local. Um backup no mesmo disco não protege contra falha desse disco.

## 9. SMTP
Preencha `SMTP_*` para ativar recuperação de senha por email. O endpoint não revela se um email está registado.

## 10. Firewall
Permita somente SSH e as portas HTTP/HTTPS no servidor. A porta 3000 deve ficar acessível apenas localmente ou pela rede interna do proxy reverso.
