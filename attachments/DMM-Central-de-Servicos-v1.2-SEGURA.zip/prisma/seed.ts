import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();
const services = [
  { name:'Monografias', slug:'monografias', category:'Trabalhos Académicos', description:'Estruturação, revisão, formatação e organização de monografias.', icon:'book-open' },
  { name:'Formatação APA / ABNT', slug:'formatacao-apa-abnt', category:'Trabalhos Académicos', description:'Formatação de trabalhos conforme a norma solicitada.', icon:'file-text' },
  { name:'Trabalhos individuais e em grupo', slug:'trabalhos-academicos', category:'Trabalhos Académicos', description:'Organização e preparação de trabalhos académicos com formulário inteligente.', icon:'users' },
  { name:'Convites e cartões', slug:'convites-cartoes', category:'Design e Impressão', description:'Artes personalizadas para eventos, celebrações e divulgação.', icon:'palette' },
  { name:'Edição de fotografias', slug:'edicao-fotos', category:'Design e Impressão', description:'Tratamento, recorte, fundo, qualidade e ajustes de imagem.', icon:'image' },
  { name:'Painéis, cartazes e artes', slug:'paineis-cartazes', category:'Design e Impressão', description:'Materiais visuais personalizados para impressão e redes sociais.', icon:'layout' },
  { name:'Configuração de computadores', slug:'configuracao-pc', category:'Informática e Tecnologia', description:'Configuração, instalação e assistência de sistemas.', icon:'monitor' },
  { name:'Websites e sistemas personalizados', slug:'websites-sistemas', category:'Informática e Tecnologia', description:'Criação de websites e soluções digitais sob medida.', icon:'code' },
  { name:'Redes e software', slug:'redes-software', category:'Informática e Tecnologia', description:'Configuração de redes, programas e ambientes de trabalho.', icon:'network' },
  { name:'Impressões e digitalizações', slug:'impressoes-digitalizacoes', category:'Outros Serviços', description:'Preparação e apoio em materiais impressos e digitalizados.', icon:'printer' },
];
async function main(){
  const email=(process.env.ADMIN_EMAIL||'menezesdaniel451@gmail.com').toLowerCase();
  const password=process.env.ADMIN_PASSWORD;
  if(!password) throw new Error('ADMIN_PASSWORD não configurado.');
  const existing=await prisma.user.findUnique({where:{email}});
  if(!existing){
    await prisma.user.create({data:{name:'Daniel Menezes Monteiro',email,passwordHash:await bcrypt.hash(password,12),role:Role.ADMIN,phone:'923078760',city:'Benguela'}});
    console.log('Administrador inicial criado.');
  } else if(existing.role!=='ADMIN') {
    await prisma.user.update({where:{id:existing.id},data:{role:Role.ADMIN}});
  } else console.log('Administrador já existe; senha não foi alterada.');
  for(const s of services) await prisma.service.upsert({where:{slug:s.slug},update:s,create:s});
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(()=>prisma.$disconnect());
