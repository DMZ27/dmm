import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();
const services=[
['Monografias','monografias','Trabalhos Académicos','Estruturação, revisão, formatação e organização de monografias.','book-open'],
['Formatação APA / ABNT','formatacao-apa-abnt','Trabalhos Académicos','Formatação de trabalhos conforme a norma solicitada.','file-text'],
['Trabalhos individuais e em grupo','trabalhos-academicos','Trabalhos Académicos','Organização e preparação de trabalhos académicos com formulário inteligente.','users'],
['Convites e cartões','convites-cartoes','Design e Impressão','Artes personalizadas para eventos, celebrações e divulgação.','palette'],
['Edição de fotografias','edicao-fotos','Design e Impressão','Tratamento, recorte, fundo, qualidade e ajustes de imagem.','image'],
['Painéis, cartazes e artes','paineis-cartazes','Design e Impressão','Materiais visuais personalizados para impressão e redes sociais.','layout'],
['Configuração de computadores','configuracao-pc','Informática e Tecnologia','Configuração, instalação e assistência de sistemas.','monitor'],
['Websites e sistemas personalizados','websites-sistemas','Informática e Tecnologia','Criação de websites e soluções digitais sob medida.','code'],
['Redes e software','redes-software','Informática e Tecnologia','Configuração de redes, programas e ambientes de trabalho.','network'],
['Impressões e digitalizações','impressoes-digitalizacoes','Outros Serviços','Preparação e apoio em materiais impressos e digitalizados.','printer']];
try{
 const email=(process.env.ADMIN_EMAIL||'menezesdaniel451@gmail.com').toLowerCase(); const password=process.env.ADMIN_PASSWORD;
 if(!password) throw new Error('ADMIN_PASSWORD não configurado.');
 const existing=await prisma.user.findUnique({where:{email}});
 if(!existing) await prisma.user.create({data:{name:'Daniel Menezes Monteiro',email,passwordHash:await bcrypt.hash(password,12),role:Role.ADMIN,phone:'923078760',city:'Benguela'}});
 else if(existing.role!=='ADMIN') await prisma.user.update({where:{id:existing.id},data:{role:Role.ADMIN}});
 for(const [name,slug,category,description,icon] of services) await prisma.service.upsert({where:{slug},update:{name,category,description,icon},create:{name,slug,category,description,icon}});
} finally { await prisma.$disconnect(); }
